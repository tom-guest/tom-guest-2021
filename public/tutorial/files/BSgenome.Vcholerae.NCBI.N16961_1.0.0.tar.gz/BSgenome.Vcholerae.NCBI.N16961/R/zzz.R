###
###

.pkgname <- "BSgenome.Vcholerae.NCBI.N16961"

.seqnames <- c("NC_002505.1","NC_002506.1")

.circ_seqs <- NULL

.mseqnames <- NULL

.onLoad <- function(libname, pkgname)
{
    if (pkgname != .pkgname)
        stop("package name (", pkgname, ") is not ",
             "the expected name (", .pkgname, ")")
    extdata_dirpath <- system.file("extdata", package=pkgname,
                                   lib.loc=libname, mustWork=TRUE)

    ## Make and export BSgenome object.
    bsgenome <- BSgenome(
        organism="Vibrio cholerae",
        common_name="V. cholerae",
        provider="NCBI",
        provider_version="ASM674v1",
        release_date="2014/02",
        release_name="N16961",
        source_url="https://www.ncbi.nlm.nih.gov/genome/?term=Vibrio%20cholerae",
        seqnames=.seqnames,
        circ_seqs=.circ_seqs,
        mseqnames=.mseqnames,
        seqs_pkgname=pkgname,
        seqs_dirpath=extdata_dirpath
    )

    ns <- asNamespace(pkgname)

    objname <- pkgname
    assign(objname, bsgenome, envir=ns)
    namespaceExport(ns, objname)

    old_objname <- "Vcholerae"
    assign(old_objname, bsgenome, envir=ns)
    namespaceExport(ns, old_objname)
}

